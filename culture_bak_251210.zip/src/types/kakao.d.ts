declare global {
    interface Window {
        kakao: any;
    }
}

export { };
